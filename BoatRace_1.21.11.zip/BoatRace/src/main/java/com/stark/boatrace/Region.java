package com.stark.boatrace;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;

public class Region {

    final String world;
    final int minX, minY, minZ, maxX, maxY, maxZ;

    Region(String world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        this.world = world;
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
    }

    static Region of(Location a, Location b) {
        return new Region(a.getWorld().getName(),
                Math.min(a.getBlockX(), b.getBlockX()), Math.min(a.getBlockY(), b.getBlockY()), Math.min(a.getBlockZ(), b.getBlockZ()),
                Math.max(a.getBlockX(), b.getBlockX()), Math.max(a.getBlockY(), b.getBlockY()), Math.max(a.getBlockZ(), b.getBlockZ()));
    }

    /** Touch check: small margin around the region so standing on / next to it counts. */
    boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        double x = l.getX(), y = l.getY(), z = l.getZ();
        return x >= minX - 0.3 && x < maxX + 1.3
                && z >= minZ - 0.3 && z < maxZ + 1.3
                && y >= minY - 1 && y < maxY + 2;
    }

    void save(ConfigurationSection s) {
        s.set("world", world);
        s.set("minX", minX);
        s.set("minY", minY);
        s.set("minZ", minZ);
        s.set("maxX", maxX);
        s.set("maxY", maxY);
        s.set("maxZ", maxZ);
    }

    static Region load(ConfigurationSection s) {
        if (s == null || !s.contains("world")) return null;
        return new Region(s.getString("world"),
                s.getInt("minX"), s.getInt("minY"), s.getInt("minZ"),
                s.getInt("maxX"), s.getInt("maxY"), s.getInt("maxZ"));
    }
}
