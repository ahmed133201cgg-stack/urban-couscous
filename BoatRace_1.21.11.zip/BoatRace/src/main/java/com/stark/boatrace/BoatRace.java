package com.stark.boatrace;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BoatRace extends JavaPlugin implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private static class Race {
        final Entity boat;
        final long startTime;

        Race(Entity boat, long startTime) {
            this.boat = boat;
            this.startTime = startTime;
        }
    }

    private Region start, finish, spawnZone;
    private Location returnLoc;
    private final Set<UUID> pending = new HashSet<>();
    private final Map<UUID, Race> races = new HashMap<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private NamespacedKey wandKey;

    @Override
    public void onEnable() {
        wandKey = new NamespacedKey(this, "wand");
        saveDefaultConfig();
        loadRegions();
        for (String id : getConfig().getStringList("pending")) {
            try {
                pending.add(UUID.fromString(id));
            } catch (IllegalArgumentException ignored) {
            }
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 2L, 2L);
    }

    @Override
    public void onDisable() {
        for (Map.Entry<UUID, Race> en : races.entrySet()) {
            en.getValue().boat.remove();
            pending.add(en.getKey());
        }
        races.clear();
        savePending();
    }

    private void savePending() {
        List<String> ids = new ArrayList<>();
        for (UUID id : pending) ids.add(id.toString());
        getConfig().set("pending", ids);
        saveConfig();
    }

    // ---------------------------------------------------------------- config

    private void loadRegions() {
        start = Region.load(getConfig().getConfigurationSection("start"));
        finish = Region.load(getConfig().getConfigurationSection("finish"));
        spawnZone = Region.load(getConfig().getConfigurationSection("spawn"));
        returnLoc = null;
        if (getConfig().contains("return.world")) {
            org.bukkit.World w = Bukkit.getWorld(getConfig().getString("return.world"));
            if (w != null) {
                returnLoc = new Location(w,
                        getConfig().getDouble("return.x"), getConfig().getDouble("return.y"), getConfig().getDouble("return.z"),
                        (float) getConfig().getDouble("return.yaw"), (float) getConfig().getDouble("return.pitch"));
            }
        }
    }

    private void saveRegions() {
        getConfig().set("start", null);
        getConfig().set("finish", null);
        getConfig().set("spawn", null);
        if (spawnZone != null) spawnZone.save(getConfig().createSection("spawn"));
        if (start != null) start.save(getConfig().createSection("start"));
        if (finish != null) finish.save(getConfig().createSection("finish"));
        getConfig().set("return", null);
        if (returnLoc != null) {
            getConfig().set("return.world", returnLoc.getWorld().getName());
            getConfig().set("return.x", returnLoc.getX());
            getConfig().set("return.y", returnLoc.getY());
            getConfig().set("return.z", returnLoc.getZ());
            getConfig().set("return.yaw", returnLoc.getYaw());
            getConfig().set("return.pitch", returnLoc.getPitch());
        }
        saveConfig();
    }

    // ---------------------------------------------------------------- race loop

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            Race r = races.get(p.getUniqueId());
            if (r != null) {
                if (!r.boat.isValid() || !r.boat.getPassengers().contains(p)) {
                    cancelRace(p);
                    continue;
                }
                long ms = System.currentTimeMillis() - r.startTime;
                p.sendActionBar(LEGACY.deserialize(hotbar(ms)));
                if (finish != null && finish.contains(p.getLocation())) {
                    finishRace(p, r);
                } else if (spawnZone != null && spawnZone.contains(p.getLocation())) {
                    cancelRace(p);
                    p.showTitle(Title.title(
                            LEGACY.deserialize("&c&l\u2716 RACE CANCELLED \u2716"),
                            LEGACY.deserialize("&7You reached spawn"),
                            Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofSeconds(1))));
                    p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                }
            } else if (start != null && start.contains(p.getLocation())
                    && (spawnZone == null || !spawnZone.contains(p.getLocation()))
                    && !p.isDead() && p.getGameMode() != GameMode.SPECTATOR) {
                startRace(p);
            }
        }
    }

    private EntityType boatType() {
        try {
            return EntityType.valueOf("OAK_BOAT");
        } catch (IllegalArgumentException e) {
            return EntityType.valueOf("BOAT");
        }
    }

    private void startRace(Player p) {
        if (p.isInsideVehicle()) p.leaveVehicle();
        Location loc = p.getLocation();
        Entity boat = loc.getWorld().spawnEntity(loc, boatType());
        boat.setPersistent(false);
        boat.addPassenger(p);
        races.put(p.getUniqueId(), new Race(boat, System.currentTimeMillis()));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
    }

    private void finishRace(Player p, Race r) {
        races.remove(p.getUniqueId());
        long ms = System.currentTimeMillis() - r.startTime;
        Location out = r.boat.getLocation();
        p.leaveVehicle();
        r.boat.remove();
        p.teleport(out.add(0, 0.2, 0));

        Title title = Title.title(
                LEGACY.deserialize("&e&l\u00BB FINISH! \u00AB"),
                LEGACY.deserialize("&f" + format(ms)),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1)));
        p.showTitle(title);
        p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);

        if (returnLoc != null) {
            UUID id = p.getUniqueId();
            Bukkit.getScheduler().runTaskLater(this, () -> {
                Player pl = Bukkit.getPlayer(id);
                if (pl != null && pl.isOnline() && !races.containsKey(id) && returnLoc != null) {
                    pl.teleport(returnLoc);
                }
            }, 60L);
        }
    }

    private void cancelRace(Player p) {
        Race r = races.remove(p.getUniqueId());
        if (r != null) r.boat.remove();
    }

    private static String hotbar(long ms) {
        long total = ms / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        return "&2&l[ &a&lH &f&l" + h + " &8| &a&lM &f&l" + m + " &8| &a&lS &f&l" + s + " &2&l]";
    }

    private static String format(long ms) {
        long total = ms / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        return h + "h " + m + "m " + s + "s";
    }

    private boolean isRaceBoat(Entity e) {
        for (Race r : races.values()) {
            if (r.boat.getUniqueId().equals(e.getUniqueId())) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onExit(VehicleExitEvent e) {
        if (e.getExited() instanceof Player p && races.containsKey(p.getUniqueId())
                && isRaceBoat(e.getVehicle())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBoatDamage(VehicleDamageEvent e) {
        if (isRaceBoat(e.getVehicle())) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (races.containsKey(id)) {
            cancelRace(e.getPlayer());
            pending.add(id);
            savePending();
        }
        selections.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (!pending.remove(id)) return;
        savePending();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline()) return;
            if (p.isInsideVehicle()) p.leaveVehicle();
            Location spawn = returnLoc != null ? returnLoc : Bukkit.getWorlds().get(0).getSpawnLocation();
            p.teleport(spawn);
            p.showTitle(Title.title(
                    LEGACY.deserialize("&c&l\u2716 RACE CANCELLED \u2716"),
                    LEGACY.deserialize("&7You left during the race"),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1))));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        }, 5L);
    }

    @EventHandler
    public void onWand(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType() != Material.GOLDEN_AXE || !item.hasItemMeta()) return;
        if (!item.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE)) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("boatrace.admin")) return;

        e.setCancelled(true);
        Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
        Location l = e.getClickedBlock().getLocation();
        int idx = a == Action.LEFT_CLICK_BLOCK ? 0 : 1;
        sel[idx] = l;
        p.sendMessage(LEGACY.deserialize("&aPos" + (idx + 1) + " &7= &f" + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ()));
    }

    // ---------------------------------------------------------------- command

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("leave")) {
            Player target = p;
            if (args.length > 1) {
                if (!p.hasPermission("boatrace.admin")) {
                    p.sendMessage(LEGACY.deserialize("&cNo permission."));
                    return true;
                }
                target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    p.sendMessage(LEGACY.deserialize("&cPlayer not found."));
                    return true;
                }
            }
            if (!races.containsKey(target.getUniqueId())) {
                p.sendMessage(LEGACY.deserialize(target == p ? "&cYou are not in a race." : "&cThat player is not in a race."));
                return true;
            }
            cancelRace(target);
            Location spawn = returnLoc != null ? returnLoc : Bukkit.getWorlds().get(0).getSpawnLocation();
            target.teleport(spawn);
            target.showTitle(Title.title(
                    LEGACY.deserialize("&c&l\u2716 RACE CANCELLED \u2716"),
                    LEGACY.deserialize("&7You left the race"),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofSeconds(1))));
            return true;
        }
        if (!p.hasPermission("boatrace.admin")) {
            p.sendMessage(LEGACY.deserialize("&cNo permission."));
            return true;
        }
        if (args.length == 0) {
            p.sendMessage(LEGACY.deserialize("&e/br wand &7| &e/br setstart &7| &e/br setfinish &7| &e/br setspawn &7| &e/br setreturn &7| &e/br leave [player] &7| &e/br clear &7| &e/br reload"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "wand" -> {
                ItemStack wand = new ItemStack(Material.GOLDEN_AXE);
                ItemMeta meta = wand.getItemMeta();
                meta.displayName(LEGACY.deserialize("&e&lBoatRace Wand"));
                meta.lore(List.of(LEGACY.deserialize("&7Left click = Pos1"), LEGACY.deserialize("&7Right click = Pos2")));
                meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
                wand.setItemMeta(meta);
                p.getInventory().addItem(wand);
                p.sendMessage(LEGACY.deserialize("&aTake the wand."));
            }
            case "setstart", "setfinish", "setspawn" -> {
                Location[] sel = selections.get(p.getUniqueId());
                if (sel == null || sel[0] == null || sel[1] == null) {
                    p.sendMessage(LEGACY.deserialize("&cSelect Pos1 & Pos2 with the wand first."));
                    return true;
                }
                if (!sel[0].getWorld().equals(sel[1].getWorld())) {
                    p.sendMessage(LEGACY.deserialize("&cBoth positions must be in the same world."));
                    return true;
                }
                Region r = Region.of(sel[0], sel[1]);
                if (args[0].equalsIgnoreCase("setstart")) {
                    start = r;
                    p.sendMessage(LEGACY.deserialize("&aStart region set."));
                } else if (args[0].equalsIgnoreCase("setspawn")) {
                    spawnZone = r;
                    p.sendMessage(LEGACY.deserialize("&aSpawn region set. Racers who enter it leave the race."));
                } else {
                    finish = r;
                    p.sendMessage(LEGACY.deserialize("&aFinish region set."));
                }
                saveRegions();
            }
            case "setreturn" -> {
                returnLoc = p.getLocation();
                saveRegions();
                p.sendMessage(LEGACY.deserialize("&aReturn point set. Players return here 3s after finishing."));
            }
            case "clear" -> {
                start = null;
                finish = null;
                spawnZone = null;
                saveRegions();
                for (UUID id : new ArrayList<>(races.keySet())) {
                    Player rp = Bukkit.getPlayer(id);
                    if (rp != null) cancelRace(rp);
                }
                races.clear();
                p.sendMessage(LEGACY.deserialize("&aRegions cleared."));
            }
            case "reload" -> {
                reloadConfig();
                loadRegions();
                p.sendMessage(LEGACY.deserialize("&aReloaded."));
            }
            default -> p.sendMessage(LEGACY.deserialize("&e/br wand | setstart | setfinish | setspawn | setreturn | leave | clear | reload"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            if (!sender.hasPermission("boatrace.admin")) return List.of("leave");
            return List.of("wand", "setstart", "setfinish", "setspawn", "setreturn", "leave", "clear", "reload");
        }
        return List.of();
    }
}
